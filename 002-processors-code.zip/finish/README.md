Alice Fixtures and Faker (in Symfony2)
======================================

Well hi there! This repository holds the code and script
for the KnpUniversity lesson called:

[Making Fixtures Awesome with Alice](http://knpuniversity.com/screencast/alice-fixtures)


